#!/bin/bash

echo $1 | sed s/STUB//
